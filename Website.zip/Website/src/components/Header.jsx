import { useState, useEffect, useRef } from 'react'
import { Link, useLocation } from 'react-router-dom'

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false)
  const [activeDropdown, setActiveDropdown] = useState(null)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const location = useLocation()
  const dropdownRef = useRef(null)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setActiveDropdown(null)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  const isActive = (path) => location.pathname === path

  const solutionsItems = [
    { name: 'Cybersecurity & ISMS', slug: 'cybersecurity-isms' },
    { name: 'Data Privacy & Governance', slug: 'data-privacy-governance' },
    { name: 'Quality & IT Compliance', slug: 'quality-it-compliance' },
    { name: 'ERP & Digital Solutions', slug: 'erp-digital-solutions' },
    { name: 'ISO Certifications', slug: 'iso-certifications' },
    { name: 'POSH & Legal Compliance', slug: 'posh-legal-compliance' },
    { name: 'Environmental & Energy Audits', slug: 'environmental-energy-audits' },
  ]

  const trainingItems = [
    { name: 'Cybersecurity Training', slug: 'cybersecurity-training' },
    { name: 'Data Privacy Training', slug: 'data-privacy-training' },
    { name: 'Certified DPO Training', slug: 'certified-dpo-training' },
    { name: 'POSH Training', slug: 'posh-training' },
    { name: 'ISO Training Programs', slug: 'iso-training' },
    { name: 'Data Engineering Training', slug: 'data-engineering-training' },
  ]

  const homeItems = [
    { name: 'Overview', path: '/' },
    { name: 'Services Snapshot', path: '/#solutions' },
    { name: 'Training Highlights', path: '/#training' },
    { name: 'Testimonials Preview', path: '/#testimonials' },
    { name: 'Contact CTA', path: '/contact' },
  ]

  const aboutItems = [
    { name: 'Company Story', path: '/about#story' },
    { name: 'Vision & Mission', path: '/about#vision' },
    { name: 'Leadership', path: '/about#leadership' },
    { name: 'Certifications', path: '/about#certifications' },
    { name: 'Read More Page', path: '/about' },
  ]

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        isScrolled
          ? 'bg-white shadow-lg'
          : 'bg-white bg-opacity-95 backdrop-blur-sm'
      }`}
    >
      {/* Top info bar */}
      <div className="bg-primary-navy text-white text-xs sm:text-sm">
        <div className="container mx-auto px-4 lg:px-8 py-2 flex flex-col md:flex-row md:items-center md:justify-between gap-2">
          <div className="flex flex-wrap items-center gap-4">
            <a href="mailto:info@shiverainfotech.com" className="flex items-center gap-1 hover:text-primary-teal transition-colors">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
              </svg>
              <span>info@shiverainfotech.com</span>
            </a>
            <div className="flex items-center gap-1">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
              </svg>
              <a href="tel:80878250238" className="hover:text-primary-teal transition-colors">
                80878250238
              </a>
              <span className="mx-1 text-gray-400">|</span>
              <a href="tel:78878888171" className="hover:text-primary-teal transition-colors">
                78878888171
              </a>
            </div>
            <div className="flex items-center gap-1 text-gray-200">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 11c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5.1 20.9A9 9 0 1118.9 7.1 9 9 0 015.1 20.9z" />
              </svg>
              <span>Baner-Pahan Link Road, Pune</span>
            </div>
          </div>
          <div className="flex items-center justify-start md:justify-end gap-3 text-gray-200">
            <a href="#" aria-label="Instagram" className="hover:text-primary-teal transition-colors">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <rect x="3" y="3" width="18" height="18" rx="5" ry="5" />
                <path d="M16 11.37A4 4 0 1112.63 8 4 4 0 0116 11.37z" />
                <circle cx="17.5" cy="6.5" r="1.5" />
              </svg>
            </a>
            <a href="#" aria-label="LinkedIn" className="hover:text-primary-teal transition-colors">
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                <path d="M4.98 3.5C4.98 4.88 3.88 6 2.5 6S0 4.88 0 3.5 1.12 1 2.5 1 4.98 2.12 4.98 3.5zM.22 8.25h4.56V24H.22zM8.7 8.25h4.37v2.13h.06c.61-1.16 2.1-2.38 4.33-2.38 4.63 0 5.48 3.05 5.48 7.02V24h-4.56v-7.41c0-1.77-.03-4.05-2.47-4.05-2.47 0-2.85 1.93-2.85 3.93V24H8.7z" />
              </svg>
            </a>
            <a href="#" aria-label="Facebook" className="hover:text-primary-teal transition-colors">
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                <path d="M22 12a10 10 0 10-11.5 9.87v-6.99H7.9V12h2.6V9.8c0-2.57 1.53-3.99 3.87-3.99 1.12 0 2.29.2 2.29.2v2.52h-1.29c-1.27 0-1.67.79-1.67 1.6V12h2.84l-.45 2.88h-2.39v6.99A10 10 0 0022 12z" />
              </svg>
            </a>
            <a href="#" aria-label="Twitter" className="hover:text-primary-teal transition-colors">
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                <path d="M22.46 6c-.77.35-1.6.58-2.46.69a4.27 4.27 0 001.88-2.37 8.48 8.48 0 01-2.7 1.04 4.24 4.24 0 00-7.3 3.87A12.06 12.06 0 013 4.79a4.24 4.24 0 001.31 5.66 4.2 4.2 0 01-1.92-.53v.05a4.24 4.24 0 003.4 4.15 4.3 4.3 0 01-1.91.07 4.25 4.25 0 003.96 2.95A8.51 8.51 0 012 19.54a12 12 0 006.29 1.84c7.55 0 11.68-6.26 11.68-11.68 0-.18 0-.35-.01-.53A8.33 8.33 0 0022.46 6z" />
              </svg>
            </a>
          </div>
        </div>
      </div>

      <nav className="container mx-auto px-4 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2 z-50">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-primary-teal rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-xl">S</span>
              </div>
              <div className="ml-3">
                <div className="text-lg font-bold text-primary-navy">
                  SHIVERA INFOTECH
                </div>
                <div className="text-xs text-gray-600">LLP</div>
              </div>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-1" ref={dropdownRef}>
            <Link
              to="/"
              className={`px-4 py-2 rounded-lg transition-colors relative ${
                isActive('/')
                  ? 'text-primary-teal font-semibold'
                  : 'text-gray-700 hover:text-primary-teal'
              }`}
              onMouseEnter={() => setActiveDropdown('home')}
              onMouseLeave={() => setActiveDropdown(null)}
            >
              Home
              {activeDropdown === 'home' && (
                <div className="absolute top-full left-0 mt-2 w-56 bg-white rounded-lg shadow-xl border border-gray-200 py-2">
                  {homeItems.map((item) => (
                    <Link
                      key={item.name}
                      to={item.path}
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-primary-teal hover:text-white transition-colors"
                    >
                      {item.name}
                    </Link>
                  ))}
                </div>
              )}
            </Link>

            <Link
              to="/about"
              className={`px-4 py-2 rounded-lg transition-colors relative ${
                isActive('/about')
                  ? 'text-primary-teal font-semibold'
                  : 'text-gray-700 hover:text-primary-teal'
              }`}
              onMouseEnter={() => setActiveDropdown('about')}
              onMouseLeave={() => setActiveDropdown(null)}
            >
              About Us
              {activeDropdown === 'about' && (
                <div className="absolute top-full left-0 mt-2 w-56 bg-white rounded-lg shadow-xl border border-gray-200 py-2">
                  {aboutItems.map((item) => (
                    <Link
                      key={item.name}
                      to={item.path}
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-primary-teal hover:text-white transition-colors"
                    >
                      {item.name}
                    </Link>
                  ))}
                </div>
              )}
            </Link>

            <div
              className="relative"
              onMouseEnter={() => setActiveDropdown('solutions')}
              onMouseLeave={() => setActiveDropdown(null)}
            >
              <button
                className={`px-4 py-2 rounded-lg transition-colors flex items-center ${
                  location.pathname.startsWith('/solutions')
                    ? 'text-primary-teal font-semibold'
                    : 'text-gray-700 hover:text-primary-teal'
                }`}
              >
                Solutions
                <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>
              {activeDropdown === 'solutions' && (
                <div className="absolute top-full left-0 mt-2 w-64 bg-white rounded-lg shadow-xl border border-gray-200 py-2">
                  {solutionsItems.map((item) => (
                    <Link
                      key={item.slug}
                      to={`/solutions/${item.slug}`}
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-primary-teal hover:text-white transition-colors"
                    >
                      {item.name}
                    </Link>
                  ))}
                </div>
              )}
            </div>

            <div
              className="relative"
              onMouseEnter={() => setActiveDropdown('training')}
              onMouseLeave={() => setActiveDropdown(null)}
            >
              <button
                className={`px-4 py-2 rounded-lg transition-colors flex items-center ${
                  location.pathname === '/training'
                    ? 'text-primary-teal font-semibold'
                    : 'text-gray-700 hover:text-primary-teal'
                }`}
              >
                Training & Certifications
                <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>
              {activeDropdown === 'training' && (
                <div className="absolute top-full left-0 mt-2 w-64 bg-white rounded-lg shadow-xl border border-gray-200 py-2">
                  {trainingItems.map((item) => (
                    <Link
                      key={item.slug}
                      to="/training"
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-primary-teal hover:text-white transition-colors"
                    >
                      {item.name}
                    </Link>
                  ))}
                </div>
              )}
            </div>

            <Link
              to="/testimonials"
              className={`px-4 py-2 rounded-lg transition-colors ${
                isActive('/testimonials')
                  ? 'text-primary-teal font-semibold'
                  : 'text-gray-700 hover:text-primary-teal'
              }`}
            >
              Testimonials
            </Link>

            <Link
              to="/careers"
              className={`px-4 py-2 rounded-lg transition-colors ${
                isActive('/careers')
                  ? 'text-primary-teal font-semibold'
                  : 'text-gray-700 hover:text-primary-teal'
              }`}
            >
              Careers
            </Link>

            <Link
              to="/collaboration"
              className={`px-4 py-2 rounded-lg transition-colors ${
                isActive('/collaboration')
                  ? 'text-primary-teal font-semibold'
                  : 'text-gray-700 hover:text-primary-teal'
              }`}
            >
              Why Us
            </Link>

            <Link
              to="/contact"
              className={`px-4 py-2 rounded-lg transition-colors ${
                isActive('/contact')
                  ? 'text-primary-teal font-semibold'
                  : 'text-gray-700 hover:text-primary-teal'
              }`}
            >
              Contact Us
            </Link>

            <Link
              to="/contact"
              className="ml-4 bg-primary-teal text-white px-6 py-2 rounded-lg font-semibold hover:bg-opacity-90 transition-all shadow-md hover:shadow-lg"
            >
              ✅ Schedule a Consultation
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden z-50 p-2"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            <svg className="w-6 h-6 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {isMobileMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden fixed inset-0 top-24 bg-white z-40 overflow-y-auto">
            <div className="px-4 py-6 space-y-4">
              <Link to="/" className="block py-2 text-gray-700 hover:text-primary-teal" onClick={() => setIsMobileMenuOpen(false)}>Home</Link>
              <Link to="/about" className="block py-2 text-gray-700 hover:text-primary-teal" onClick={() => setIsMobileMenuOpen(false)}>About Us</Link>
              <Link to="/solutions" className="block py-2 text-gray-700 hover:text-primary-teal" onClick={() => setIsMobileMenuOpen(false)}>Solutions</Link>
              <Link to="/training" className="block py-2 text-gray-700 hover:text-primary-teal" onClick={() => setIsMobileMenuOpen(false)}>Training & Certifications</Link>
              <Link to="/testimonials" className="block py-2 text-gray-700 hover:text-primary-teal" onClick={() => setIsMobileMenuOpen(false)}>Testimonials</Link>
              <Link to="/careers" className="block py-2 text-gray-700 hover:text-primary-teal" onClick={() => setIsMobileMenuOpen(false)}>Careers</Link>
              <Link to="/collaboration" className="block py-2 text-gray-700 hover:text-primary-teal" onClick={() => setIsMobileMenuOpen(false)}>Why Us</Link>
              <Link to="/contact" className="block py-2 text-gray-700 hover:text-primary-teal" onClick={() => setIsMobileMenuOpen(false)}>Contact Us</Link>
              <Link
                to="/contact"
                className="block bg-primary-teal text-white px-6 py-3 rounded-lg font-semibold text-center mt-4"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                ✅ Schedule a Consultation
              </Link>
            </div>
          </div>
        )}
      </nav>
    </header>
  )
}

export default Header

