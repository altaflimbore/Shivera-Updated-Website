import { Link } from 'react-router-dom'

const Footer = () => {
  return (
    <footer className="bg-primary-navy text-white mt-20">
      <div className="container mx-auto px-4 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center mb-4">
              <div className="w-10 h-10 bg-primary-teal rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-xl">S</span>
              </div>
              <div className="ml-3">
                <div className="text-lg font-bold">SHIVERA INFOTECH</div>
                <div className="text-xs text-gray-400">LLP</div>
              </div>
            </div>
            <p className="text-gray-300 text-sm mb-4">
              Trusted IT, Data Privacy & Compliance Consulting Partner
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/" className="text-gray-300 hover:text-primary-teal transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-gray-300 hover:text-primary-teal transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link to="/solutions" className="text-gray-300 hover:text-primary-teal transition-colors">
                  Solutions
                </Link>
              </li>
              <li>
                <Link to="/training" className="text-gray-300 hover:text-primary-teal transition-colors">
                  Training
                </Link>
              </li>
              <li>
                <Link to="/testimonials" className="text-gray-300 hover:text-primary-teal transition-colors">
                  Testimonials
                </Link>
              </li>
              <li>
                <Link to="/careers" className="text-gray-300 hover:text-primary-teal transition-colors">
                  Careers
                </Link>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="font-semibold mb-4">Services</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/solutions/cybersecurity-isms" className="text-gray-300 hover:text-primary-teal transition-colors">
                  Cybersecurity & ISMS
                </Link>
              </li>
              <li>
                <Link to="/solutions/data-privacy-governance" className="text-gray-300 hover:text-primary-teal transition-colors">
                  Data Privacy & DPDP
                </Link>
              </li>
              <li>
                <Link to="/solutions/iso-certifications" className="text-gray-300 hover:text-primary-teal transition-colors">
                  ISO Certifications
                </Link>
              </li>
              <li>
                <Link to="/solutions/quality-it-compliance" className="text-gray-300 hover:text-primary-teal transition-colors">
                  IT CSV & GxP
                </Link>
              </li>
              <li>
                <Link to="/solutions/erp-digital-solutions" className="text-gray-300 hover:text-primary-teal transition-colors">
                  ERPNext Implementation
                </Link>
              </li>
              <li>
                <Link to="/solutions/posh-legal-compliance" className="text-gray-300 hover:text-primary-teal transition-colors">
                  POSH Compliance
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start">
                <svg className="w-5 h-5 mr-2 text-primary-teal flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                </svg>
                <div>
                  <a href="tel:80878250238" className="text-gray-300 hover:text-primary-teal transition-colors block">
                    📞 80878250238
                  </a>
                  <a href="tel:78878888171" className="text-gray-300 hover:text-primary-teal transition-colors block">
                    📞 78878888171
                  </a>
                </div>
              </li>
              <li className="flex items-start">
                <svg className="w-5 h-5 mr-2 text-primary-teal flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
                <a href="mailto:info@shiverainfotech.com" className="text-gray-300 hover:text-primary-teal transition-colors">
                  ✉️ info@shiverainfotech.com
                </a>
              </li>
              <li className="flex items-start">
                <svg className="w-5 h-5 mr-2 text-primary-teal flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 11c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5.1 20.9A9 9 0 1118.9 7.1 9 9 0 015.1 20.9z" />
                </svg>
                <span className="text-gray-300">
                  📍 B103, Vastunirvana, Baner-Pahan Link Road
                </span>
              </li>
              <li className="pt-2">
                <Link
                  to="/contact"
                  className="inline-block bg-primary-teal text-white px-6 py-2 rounded-lg font-semibold hover:bg-opacity-90 transition-all text-sm"
                >
                  Schedule Consultation
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-8 text-center text-sm text-gray-400">
          <p>&copy; {new Date().getFullYear()} SHIVERA INFOTECH LLP. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}

export default Footer

