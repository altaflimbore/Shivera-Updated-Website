import { Link } from 'react-router-dom'

const Collaboration = () => {
  const partners = [
    {
      name: 'IQSYS',
      description: 'Quality systems and compliance consulting partner specializing in ISO certifications and quality management.',
      icon: '🤝',
    },
    {
      name: 'Value Creator',
      description: 'Strategic business consulting and value creation services for enterprise transformation.',
      icon: '💼',
    },
    {
      name: 'Shekhar & Manish Consulting',
      description: 'Expert consulting services in regulatory compliance and business process optimization.',
      icon: '📋',
    },
    {
      name: 'CyberSec Expert Network',
      description: 'Cybersecurity expertise network providing advanced security solutions and threat intelligence.',
      icon: '🛡️',
    },
  ]

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary-navy to-primary-teal text-white py-16">
        <div className="container mx-auto px-4 lg:px-8">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Why Us</h1>
          <p className="text-xl text-gray-200 max-w-3xl">
            Collaboration Services & Strategic Partnerships
          </p>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="max-w-4xl mx-auto mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-primary-navy mb-6 text-center">
              Why Choose SHIVERA INFOTECH?
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                { icon: '👥', title: '20+ Years Leadership Expertise', desc: 'Combined experience across IT, privacy, and compliance domains' },
                { icon: '🏆', title: 'Certified Privacy & Cybersecurity Experts', desc: 'IAPP certified professionals and ISO lead implementers' },
                { icon: '✅', title: 'Audit-Ready Implementation Delivery', desc: 'End-to-end support ensuring regulator alignment' },
                { icon: '📋', title: 'Regulator-Aligned Compliance Solutions', desc: 'Solutions designed to meet DPDP, GDPR, and ISO standards' },
                { icon: '🌐', title: 'Cross-Industry Consulting Excellence', desc: 'Proven track record across pharma, corporate, and institutions' },
                { icon: '🤝', title: 'Implementation-First Approach', desc: 'We don\'t just consult—we implement and deliver results' },
              ].map((item, index) => (
                <div key={index} className="bg-gradient-to-br from-gray-50 to-white rounded-xl p-6 border border-gray-100 hover:shadow-lg transition-all">
                  <div className="text-4xl mb-4">{item.icon}</div>
                  <h3 className="text-xl font-bold text-primary-navy mb-2">{item.title}</h3>
                  <p className="text-gray-600">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Collaboration Partners Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-primary-navy mb-8 text-center">
              Collaboration Services
            </h2>
            <p className="text-lg text-gray-600 mb-12 text-center max-w-2xl mx-auto">
              We collaborate with trusted partners to deliver comprehensive solutions across IT, compliance, and business consulting domains.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {partners.map((partner, index) => (
                <div key={index} className="bg-white rounded-xl p-6 shadow-md hover:shadow-xl transition-all">
                  <div className="text-5xl mb-4">{partner.icon}</div>
                  <h3 className="text-2xl font-bold text-primary-navy mb-3">{partner.name}</h3>
                  <p className="text-gray-600 mb-6">{partner.description}</p>
                  <Link
                    to="/contact"
                    className="inline-flex items-center bg-primary-teal text-white px-6 py-3 rounded-lg font-semibold hover:bg-opacity-90 transition-all"
                  >
                    ➡ Connect With Partner
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Value Proposition Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-primary-navy mb-8 text-center">
              Our Value Proposition
            </h2>
            <div className="space-y-6">
              {[
                {
                  title: 'Implementation-First Approach',
                  description: 'We go beyond documentation to deliver audit-ready, regulator-aligned implementations that stand the test of time.',
                },
                {
                  title: 'Regulatory Expertise',
                  description: 'Deep understanding of DPDP, GDPR, ISO standards, and industry-specific regulations ensures compliance from day one.',
                },
                {
                  title: 'Cross-Industry Experience',
                  description: 'Proven track record across pharmaceuticals, healthcare, finance, technology, and manufacturing sectors.',
                },
                {
                  title: 'Certified Professionals',
                  description: 'Our team holds IAPP, ISO, and industry certifications ensuring expertise in privacy, security, and compliance.',
                },
              ].map((item, index) => (
                <div key={index} className="bg-gray-50 rounded-xl p-6 border-l-4 border-primary-teal">
                  <h3 className="text-xl font-bold text-primary-navy mb-2">{item.title}</h3>
                  <p className="text-gray-600">{item.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-br from-primary-navy to-primary-teal text-white">
        <div className="container mx-auto px-4 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Work With Us?
          </h2>
          <p className="text-xl text-gray-200 mb-8 max-w-2xl mx-auto">
            Experience the difference of working with a team that combines expertise, implementation excellence, and regulatory alignment.
          </p>
          <Link
            to="/contact"
            className="inline-block bg-white text-primary-navy px-10 py-4 rounded-lg font-semibold text-lg hover:bg-gray-100 transition-all shadow-xl hover:shadow-2xl transform hover:-translate-y-1"
          >
            ✅ Schedule a Consultation
          </Link>
        </div>
      </section>
    </div>
  )
}

export default Collaboration

